<?php
if (isset($properties)): foreach ($properties as $property): {
            
        }
        ?>
        <div class="col-md-4 col-md-mine" style="margin-top:20px; min-width:203px; ">
            <div style=" border:1px  #74451B solid;" >
                <?php
                $model = new Gen_model;
                $image = $model->get_property_image($property->id)
                ?>
                <?php if ($image == NULL): ?>
                    <img class="" style="height:200px; max-width:100%; min-width:200px" src='<?php echo site_url('assets/uploads/logo.png') ?>'>
                <?php else: ?>
                    <img class="" style="height:200px; max-width:100%; min-width:200px" src='<?php echo site_url('assets/uploads/' . $image->file_name) ?>'>
                <?php endif; ?>
                <div style="border:1px  #74451B solid;">
                    <a href="<?php echo site_url('property/view_details/' . $property->id) ?>">
                        <h3 class="text  text-center" style="color: #74451B;height:113px; overflow:hidden ;" >
                            <?php echo $property->name; ?>
                        </h3>
                    </a>

                </div>
                <div style="background: #74451B; border:1px  #74451B solid;">
                    <h3 class="text text-center text-sm" style="color:#fff">
                        Ksh.  <?php echo $property->price; ?>
                    </h3>
                </div>
                <div>
                    <table class="table table-bordered table-striped">
                        <tr>
                            <td>Bed</td>
                            <td><?php echo $property->bedroom; ?></td>

                        </tr>
                        <tr>
                            <td>Size</td>
                            <td><?php echo $property->size . ' ' . $property->size_unit; ?></td>

                        </tr>



                    </table>

                </div>
                <div class="stats wb-ebony-bg">
                    <!--<span class="fa fa-heart-o" rel="tooltip" title="Liked"> <strong>47</strong></span>-->
                    <span class="fa fa-eye" rel="tooltip" title="Viewed"> <strong><?php echo $property->views; ?> views</strong></span>

                    <span class="fa fa-photo pull-right" rel="tooltip" title="Photos"> <strong>12</strong></span>
                </div>
            </div>
        </div>
        <?php
    endforeach;
    echo $this->load->view('components/pagenation_v', TRUE);
endif;
?>