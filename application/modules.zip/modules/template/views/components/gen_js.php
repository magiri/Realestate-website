 

<!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
<!--    <script src="assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>-->
    <!-- Bootstrap 3.3.5 -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    