<div class="footer">
    <div class="container-fluid">
        <div class="footer-grid col-md-3 ">

            <h3>Location</h3>
            <div class="address">
                <ul>
                    <li>location></li>
                    <li> first_email; ?></li>
                    <li><span>Telephone :</span>  phone_numbers; ?></li>

                </ul>
            </div>
        </div>
        <div class="footer-grid col-md-3">
            <h3>About ebony</h3>
            <p><label>@Ebony</label> On recommend tolerably my belonging or am. Mutual has cannot beauty indeed now sussex 
                merely you. It possible no husbands jennings ye offended packages pleasant he. Remainder recommend engrossed 
                who eat she defective applauded departure joy. Get dissimilar not introduced day her apartments.

            </p>

        </div>
        <div class="footer-grid center-grid col-md-3">
            <h3>Services</h3>
            <ul>
                <li><a href="<?php echo site_url('services'); ?>">this service</a></li>
                <li><a href="<?php echo site_url('services'); ?>">this service</a></li>
                <li><a href="<?php echo site_url('services'); ?>">this service</a></li>
                <li><a href="<?php echo site_url('services'); ?>">this service</a></li>
            


            </ul>
        </div>	
        <div class="footer-grid col-md-3">
            <h3>Quick Links</h3>
            <ul>
                <!--                <li><a href="#">Featured products</a></li>
                                <li><a href="#">Jobs</a></li>-->

                <li><a href="<?php echo site_url('contacts') ?>">Customer Feedback</a></li>


            </ul>

            <div class="newsletter">
                <h4 style="color:#F86C1B;font-family:'Open Sans', sans-serif;">Subscribe To Newsletter</h4>

            </div>

        </div>

        <div class="clear"> </div>
    </div>

</div> <!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Powered by <a href="jemslab.com"> Jemslab </a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="#">Ebony Estates</a>.</strong> All rights reserved.

</footer>


