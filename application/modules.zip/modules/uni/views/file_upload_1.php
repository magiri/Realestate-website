<!DOCTYPE html>

<meta charset="utf-8">

<title>Dropzone simple example</title>


<!--
  DO NOT SIMPLY COPY THOSE LINES. Download the JS and CSS files from the
  latest release (https://github.com/enyo/dropzone/releases/latest), and
  host them yourself!
-->
<!--<script src="https://rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>
<link rel="stylesheet" href="https://rawgit.com/enyo/dropzone/master/dist/dropzone.css">-->


<p>
    This is the most minimal example of Dropzone. The upload in this example
    doesn't work, because there is no actual server to handle the file upload.
</p>

<!-- Change /upload-target to your upload address -->

<?php echo form_open_multipart('', 'class="dropzone" id="my-awesome-dropzone"') ?>
 <input name="userfile[]" type="file" multiple />
<button type="submit" class="btn">Submit</button>
<?php echo form_close(); ?>

<script type="text/javascript">
Dropzone.options.myAwesomeDropzone  = {
  paramName: "userfile", // The name that will be used to transfer the file
};
</script>
