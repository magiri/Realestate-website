<style>
    .top{
        margin-top:10px;
        margin-bottom:10px;
    }
</style>
<div class="container top">
    <div class="row">
        <div class="pull-righft">
             <a href="<?php echo site_url('management/property/edit') ?>"><button class="btn btn-default btn-lg" ><i><span class="fa fa-plus"></span></i> Add New Property<i></i></button></a>    
        </div>
    </div>
</div>