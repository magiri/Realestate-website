 

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.1.4 -->
<?php if ($enable_tables == true):  ?>
<!--<script src="assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>-->
<?php endif; ?>

