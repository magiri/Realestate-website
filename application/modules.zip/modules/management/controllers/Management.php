<?php

class Management extends MG_Controller {

    function __construct() {
        parent::__construct();

        $this->data['module'] = 'management';
    }

    public function index() {

        $this->data['subview'] = 'dashboard';

        $this->load->view('template', $this->data);
    }

    public function manage_users() {
        $this->data['page_title']="Manage Users";
        $this->load->module('tables');
        $table = new tables;

        $table->set_table('users');

        $table->set_display_cols(array(
            'username' => 'Name',
            'email' => 'Desc',
        ));
        $table->set_edit_field('user_id');
        $table->set_edit_links(array(
            'Edit' => '/auth/edit/',
            'Block' => '/auth/burn/',
        ));


        $table->all_data_output();
        $this->data['subview_string'] = $table->output();

        $this->load->view('template', $this->data);
    }

}
