<?php

class Property extends MG_Controller {

    function __construct() {
        parent::__construct();

        $this->data['module'] = 'management';
    }

    public function index() {
        $this->data['subview'] = 'property/analysis';
        $this->output();
    }

    public function all() {
        $this->data['subview'] = 'property/view_all';
        $table = 'properties';
        $columns = array(
            'name' => "Name",
            'address' => "Address",
            'yearbuilt' => 'Year');
        $links = array(
            'Edit' => "management/property/edit/",
            'Edit images' => "management/property/edit_images/",
        );

        $this->table($table, $columns, $links);
//        $this->output();
    }

    public function edit($id = NULL) {
        $update = array('category_id', 'rent_sale', 'name', 'address',
            'yearbuilt', 'description', 'image', 'no_of_units', 'size',
            'size_unit', 'price', 'includetax', 'mls', 'amentities', 'stories',
            'floorcoverings', 'rooftype', 'bathroom', 'diningroom', 'bedroom',
            'kitchen', 'livingroom', 'miscrooms', 'heating', 'cooling', 'water',
            'sewer', 'laundry', 'parking', 'swimmingpool', 'garden', 'yardgrounds',
            'handicapfeatures', 'status', 'views', 'contact_id', 'latitude',
            'longitude', 'fulladdress', 'unit', 'modified_at');
        $all = array('id', 'category_id', 'rent_sale', 'name', 'address',
            'yearbuilt', 'description', 'image', 'no_of_units', 'size',
            'size_unit', 'price', 'includetax', 'mls', 'amentities', 'stories',
            'floorcoverings', 'rooftype', 'bathroom', 'diningroom', 'bedroom',
            'kitchen', 'livingroom', 'miscrooms', 'heating', 'cooling', 'water',
            'sewer', 'laundry', 'parking', 'swimmingpool', 'garden', 'yardgrounds',
            'handicapfeatures', 'status', 'views', 'contact_id', 'latitude',
            'longitude', 'fulladdress', 'unit', 'created_at', 'modified_at');
        $model = new Gen_model;
        $model->create_model("properties");
        if ($id == NULL) {
            $this->data['property_info'] = $model->get_new($all);
            $this->load->library('form_validation');
            $this->form_validation->set_rules($this->property_form_rules());
            if ($this->form_validation->run() == TRUE) {
                $data = $model->array_in_post($update);

                if ($this->input->post('id') == '') {

                    $id = $model->insert($data);
                } else {
                    $id = $this->input->post('id');
                    $model->update($id, $data);

                    $model2 = new Gen_model;
                    $model2->create_model('p_imgs');
                    $upload = $model2->one_file_upload();
                }
                if ($upload['upload'] == TRUE) {
                    $data2['file_name'] = $upload['upload_data']['file_name'];
                    $data2['field_id'] = $id;
                    $data2['main_image'] = 1;
                    $model2->insert($data2);
                }
                redirect('management/property/edit/' . $id);
            } else {
                $this->data['validation_errors'] = validation_errors();
            }
        } else {
            $this->data['property_info'] = $model->get_by(['id' => $id]);
            if ($this->data['property_info'] == NULL) {
                $this->data['subview_string'] = 'Property Not Found';
            }
        }
        $this->get_property_image($id);
        $this->data['subview'] = 'property/edit_v';
        $this->output();
    }

    public function edit_images($id = NULL) {
        $model = new Gen_model;
        $model->create_model('p_imgs');
        $data = [];
        if ($id == NULL) {
            $image = $model->one_file_upload();

            if (!$image['upload']) {
                $this->data["error"] = $image['error'];
            } else {
                $data['file_name'] = $image['upload_data']['file_name'];
            }
            if ($this->input->post('field_id') != NULL) {
//                    $data['id'] = $this->input->post('id');
                $data['field_id'] = $this->input->post('field_id');
                $data['caption'] = $this->input->post('caption');
                $data['description'] = $this->input->post('description');
                $id = $model->update($this->input->post('id'), $data);
                redirect('management/property/edit_images/' . $data['field_id']);
            }
        }
        $model_p = new Gen_model;
        $model_p->create_model('properties');
        $this->data['property'] = $model_p->get($id);

        if ($this->data['property'] == NULL) {
            $this->data['page_title'] = 'Error!!!! ....Property Not Found';
        } else {
            $this->data['page_title'] = $this->data['property']->name;
            $this->data['p_id'] = $this->data['property']->id;
            $this->data['page_desc'] = 'Images';
            $this->data['images'] = $model->get_many_by(['field_id' => $id]);
            $this->data['subview'] = 'property/edit_images';
        }
        $this->output();
    }

    public function add_images($id = NULL) {
        $model = new Gen_model;
        $model->create_model('p_imgs');
        $images = $model->file_upload();
        $data = [];

        if ($id == null) {
            if (isset($images['error'])) {
                $this->data["error"] = $images['error'];
            } elseif (isset($images['upload_data'])) {
                foreach ($images['upload_data'] as $key => $image) {
                    $data[$key]['file_name'] = $image['file_name'];
                    $data[$key]['field_id'] = $this->input->post('field_id');
                }
                $model->insert_many($data);
                $id = $this->input->post('field_id');
            }
        }
        redirect('management/property/edit_images/' . $id);
    }

    private
            function property_form_rules() {
        $rules = array(
            array(
                'field' => 'name',
                'label' => 'Name',
                'rules' => 'required|min_length[5]'
            ),
            array(
                'field' => 'description',
                'label' => 'Description',
                'rules' => 'required|min_length[8]'
            ),
            array(
                'field' => 'category_id',
                'label' => 'Category',
                'rules' => 'required'
            ),
            array(
                'field' => 'rent_sale',
                'label' => 'Rent/sale',
                'rules' => 'required'
            ),
        );
        return $rules;
    }

    function get_property_image($id, $main = TRUE) {
        $model = new Gen_model;
        $model->create_model('p_imgs');
        if ($main == true) {
            $this->data['p_main_image'] = $model->get_by(['field_id' => $id, 'main_image' => 1]);
        } else {
            $this->data['p_images'] = $model->get_many(['field_id' => $id]);
        }
    }

}
