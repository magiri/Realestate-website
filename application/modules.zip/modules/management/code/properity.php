'id', 'category_id', 'rent_sale', 'name', 'address', 
'yearbuilt', 'description', 
'image', 'no_of_units', 'size', 
'size_unit', 'price', 'includetax', 'mls', 'amentities', 'stories',
'floorcoverings', 'rooftype', 'bathroom', 'diningroom', 'bedroom', 
'kitchen', 'livingroom', 'miscrooms', 'heating', 'cooling', 'water', 
'sewer', 'laundry', 'parking', 'swimmingpool', 'garden', 'yardgrounds', 
'handicapfeatures', 'status', 'views', 'contact_id', 'latitude',
'longitude', 'fulladdress', 'unit', 'created_at', 'modified_at'




?>