<script src="<?php echo site_url('assets/plugins/bootstrap-news/jquery.bootstrap.newsbox.js') ?>" type="text/javascript"></script>
<style type="text/css">
    .news-img{
        width:100%;
        min-height:210px;
    }
    .news-item{
        width:100%;
    }
</style>
<div class="row">
    <div class="col-md-12">
        <div class="panel-news">

            <div class="panel-newss">
                <div class="upcoming" style="overflow-y: hidden; height: 210px;">

                    <div  style="" class="news-item">
                        <img class="news-img" src="<?php echo site_url('assets/ebonyimages/advert.png') ?>">

                    </div>
                    <div  style="" class="news-item">
                        <img class="news-img" src="<?php echo site_url('assets/ebonyimages/advert.png') ?>">

                    </div>
                    <div  style="" class="news-item">
                        <img class="news-img" src="<?php echo site_url('assets/ebonyimages/advert.png') ?>">

                    </div>
                    <div  style="" class="news-item">
                        <img class="news-img" src="<?php echo site_url('assets/ebonyimages/advert.png') ?>">

                    </div>
                </div>


            </div>
          
        </div>
    </div>

</div>
<script type="text/javascript">

    $(function () {
        $(".upcoming").bootstrapNews({
            newsPerPage: 1,
            autoplay: true,
            pauseOnHover: true,
            direction: 'up',
            newsTickerInterval: 1000,
            onToDo: function () {
                //console.log(this);
            }
        });
    });
</script>