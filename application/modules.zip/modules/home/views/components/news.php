<?php
$model = new Gen_model;
$model->create_model('blog_articles');
$model->limit(3);
$model->db->order_by('modified');
$news = $model->get_many_by(['status' => 0]);
if (isset($news) and count($news) > 0):
    ?>
    <?php ?>
    <style type="text/css">
        .news-header{
            border-bottom: 1px solid #eee;

        }
        .news-div{
            background-color: #fbf7f3;
            margin-top: 20px;
        }
    </style>
    <div class="container-fluid news-div">
        <div class="news-header">
            <h3>latest news</h3>
        </div>
        <div class="row">

            <?php foreach ($news as $one): ?>
                <div class="col-md-4 col-md-mine">
                    <div class="newfs-header">
                        <h4><?php echo $one->title ?></h4>
                    </div>
                    <p>
                        <?php echo strip_tags($one->body) ?>

                    </p>
                    <a class="btn btn-info pull-right" href="<?php echo site_url('articles/viewart/'.$one->id) ?>">Read More</a>
                </div>
            <?php endforeach; ?>

        </div>
    </div>

<?php endif; ?>