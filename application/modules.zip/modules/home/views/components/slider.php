<link rel="stylesheet" href="http://cdn.bootcss.com/animate.css/3.5.1/animate.min.css">
<style type="text/css">
    .carousel{
        width:100%;
    }
    .carousel-control.right{
        background:none;
        color: #000;
    }
    .carousel-control.left{
        background:none;
        color:#000;

    }
    .slider-image{
        height:100%;
        width:100%;
        max-height:670px;
    }
</style>
<div id="home-carousel" class="carousel  slide col-md-mine" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <?php for ($i = 1; $i <= 7; $i++): ?>
            <li data-target="#home-carousel" data-slide-to="<?php echo $i ?>" class="<?php
            if ($i == 1) {
                echo "active ";
            }
            ?>"></li>
            <?php endfor; ?>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox" >
        <?php for ($i = 1; $i <= 7; $i++): ?>
            <div class="item <?php if ($i == 1) { echo "active ";} ?>">
                <div class="">
                    <img class='slider-image'   src="<?php echo site_url('assets/dimages/houses/'.$i.'.jpg') ?>" alt="...">
                    <div class="carousel-caption">
                        <?php echo $i ?>
                    </div>
                </div>
            </div>
        <?php endfor; ?>
      
            <div class="item ">
                <div class="container-fluid">
                    <img class='slider-image'   src="<?php echo site_url('assets/ebonyimages/1.jpg') ?>" alt="...">
                    <div class="carousel-caption">
                        <?php echo $i ?>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container-fluid">
                    <img class='slider-image'   src="<?php echo site_url('assets/ebonyimages/2.png') ?>" alt="...">
                    <div class="carousel-caption">
                        <?php echo $i ?>
                    </div>
                </div>
            </div>
    </div>

    <!-- Controls -->
    <a class="left carousel-control" href="#home-carousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#home-carousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<script type="text/javascript">
//    $('.carousel').carousel({
//        interval: 20
//    })
</script>