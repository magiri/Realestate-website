
<!--bootstrap validator-->

<!--gencss-->
<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/posts/style.css'); ?>">
<!--gencss-->

