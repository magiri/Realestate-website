<script src="<?php echo site_url('assets/js/jquery.min.js'); ?>" type="text/javascript"></script>

<!--bootstrap-->
<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/bootstrap/css/font-awesome.min.css'); ?>">
<!--bootsrap-->

<!--bootstrap validator-->        
<link rel="stylesheet" href="<?php echo site_url('assets/bootstrap/css/bootstrapValidator.css'); ?>"/>
<!--bootstrap validator-->

<!--gencss-->
<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/css/style.css'); ?>">
<!--gencss-->

<script type="text/javascript">
    var jsConfig = {
        base: "<?php echo site_url(); ?>"
    };
</script>



<script type="text/javascript" src="<?php echo site_url('assets/js/jquery.min.js'); ?>"></script>

<!--bootstrap-->
<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>





<script src="<?php echo site_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>

<!--bootstrap validator-->
<script type="text/javascript" src="<?php echo site_url('assets/bootstrap/js/bootstrapValidator.js'); ?>"></script>