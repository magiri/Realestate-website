<?php

class Property extends Public_Controller {

//    var $data;
//    var $template = 'template/template_v';

    function __construct() {
        parent::__construct();
        $this->data['module'] = 'property';
    }

    public function index() {
        $model = new Gen_model;
        $model->create_model('properties');
        $this->paginate(9, $model->count_by(array('status' => 1)), 'property/index/');
        $this->data['properties'] = $model->get_many_by(array('status' => 1));
        $this->data['subview'] = 'p_all';

        $this->output();
//        $this->load->view($this->template, $this->data);
    }

    public function all() {
        $model = new Gen_model;
        $model->create_model('properties');
        $this->data['properties'] = $model->get_many_by(array('status' => 1));
//        $this->data['subview'] = 'p_details';
        $this->data['subview'] = 'p_all';
        $this->load->view($this->template, $this->data);
    }

    public function view_details($id) {
        $model = new Gen_model;
        $model->create_model('properties');
        $this->data['p_details'] = $model->get_by(['id' => $id]);
        $this->data['subview'] = 'p_details';
        $this->load->view($this->template, $this->data);
    }

}
