<style type="text/css">
    *::after, *::before {
        box-sizing: border-box;
    }
    *::after, *::before {
        box-sizing: border-box;
    }
    .article-slide .carousel-indicators-mine {
        bottom: 0;
        left: 0;
        margin-left: 5px;
        width: 100%;
    }
    .carousel-indicators-mine {
        bottom: 20px;
    }
    .carousel-indicators-mine {
        bottom: 10px;
        left: 50%;
        list-style: outside none none;
        margin-left: -30%;
        padding-left: 0;
        position: absolute;
        text-align: center;
        width: 60%;
        z-index: 15;
    }
    ol, ul {
        margin-bottom: 10px;
        margin-top: 0;
    }
    * {
        box-sizing: border-box;
    }
    
    
    
    
        *::after, *::before {
        box-sizing: border-box;
    }
    *::after, *::before {
        box-sizing: border-box;
    }
    .article-slide .carousel-indicators-mine {
        bottom: 0;
        left: 0;
        margin-left: 5px;
        width: 100%;
    }
    .carousel-indicators-mine {
        bottom: 20px;
    }
    .carousel-indicators-mine {
        bottom: 10px;
        left: 50%;
        list-style: outside none none;
        margin-left: -30%;
        padding-left: 0;
        position: absolute;
        text-align: center;
        width: 60%;
        z-index: 15;
    }
    ol, ul {
        margin-bottom: 10px;
        margin-top: 0;
    }
    * {
        box-sizing: border-box;
    }



    /* Indicators list style */
    .article-slide .carousel-indicators {
        /*        bottom: 0;
                left: 0;*/
        margin-left: 5px;
        width: 100%;
    }
    /* Indicators list style */
    .article-slide .carousel-indicators-mine li {
        border: medium none;
        border-radius: 0;
        /*float: left;*/
        list-style: outside none none;
        height: 54px;
        margin-bottom: 5px;
        margin-left: 0;
        margin-right: 5px !important;
        margin-top: 0;
        width: 100px;
    }
    /* Indicators images style */
    .article-slide .carousel-indicators-mine img {
        border: 2px solid #FFFFFF;
        /*float: left;*/
        height: 54px;
        left: 0;
        width: 100px;
    }
    /* Indicators active image style */
    .article-slide .carousel-indicators-mine .active img {
        border: 2px solid #428BCA;
        opacity: 0.7;
    }
</style>